<!--Start footer-->
	<footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © {{date('Y')}} {{$settingsinfo->company_name}} (All Right Reserved).
        </div>
      </div>
    </footer>
	<!--End footer-->
   
  </div><!--End wrapper-->