<script type="text/javascript">
	location.replace("public");
</script>